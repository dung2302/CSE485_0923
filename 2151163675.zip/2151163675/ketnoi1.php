<?php
 $conn = mysqli_connect("localhost:4306", "root", "", "nguoi_dung");
    if(!$conn){
        die('Connection Failed'. mysqli_connect_error());
    }
 

?>
