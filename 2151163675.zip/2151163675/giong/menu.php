
<div class="dropdown mb-3">
    <a class="dropdown-toggle nav-link active" href="#" role="button" data-bs-toggle="dropdown" data-bs-target="#Menu">
        <i class="bi bi-ui-checks-grid"></i>
        <span class="fs-5 hide-when-collapsed p-2">Dashboard</span>
    </a>
    <div id="Menu" class="dropdown">
        <ul class="nav flex-column ml-3">
            <li class="nav-item"><a class="nav-link" href="">Dashboard Light</a></li>
            <li class="nav-item"><a class="nav-link" href="">Dashboard Dark</a></li>
            <li class="nav-item"><a class="nav-link" href="">Schedule</a></li>
            <li class="nav-item"><a class="nav-link" href="">Instructors</a></li>
        </ul>
    </div>
</div>
<div class="dropdown mb-3">
    <a class="dropdown-toggle nav-link active" href="#" role="button" data-bs-toggle="dropdown" data-bs-target="#Menu">
        <i class="bi bi-ui-checks-grid"></i>
        <span class="fs-5 hide-when-collapsed p-2">user</span>
    </a>
    <div id="Menu" class="dropdown">
        <ul class="nav flex-column ml-3">
            <li class="nav-item"><a class="nav-link" href="">users</a></li>
            <li class="nav-item"><a class="nav-link" href="">group</a></li>
            <li class="nav-item"><a class="nav-link" href="">permissions</a></li>
            
        </ul>
    </div>
</div>
